Otter Space copyright (c) 2023, David Lang (https://davidlang.design).
This font is free as per the creator's request.
If you paid for it, you were scammed.

=================================

              WELCOME

⋆ ✢ ✣ ✤ ✥ ✦ ✧ ✩ ✪ ✫ ✬ ✭ ✮ ✯ ✰ ★

             (:ᘌꇤ⁐ꃳ 三

⋆ ✢ ✣ ✤ ✥ ✦ ✧ ✩ ✪ ✫ ✬ ✭ ✮ ✯ ✰ ★

           TO OTTER SPACE

=================================

I would love to see how you use Otter Space!
Send examples via email at dblang4@duck.com.